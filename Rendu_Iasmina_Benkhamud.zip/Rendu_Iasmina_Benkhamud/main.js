
// Sélectionner plusieurs éléments
const skieur = document.getElementById("skieur");
const pierre = document.getElementById("pierre");
const bouton = document.getElementById("bouton");

// Sélectionner un élément
document.addEventListener("keydown", function(event) {
    jump();
});

// Réagir à un évènement
bouton.addEventListener("click",(event) => {
console.log("Bouton cliqué");
console.log(event);
console.log(event.currentTarget);
});

// Modifier le style CSS
function jump () {
    if (skieur.classList != "jump") {
        skieur.classList.add("jump")
    }
    setTimeout( function() {
        skieur.classList.remove("jump")
    }, 300)
}    

// Supprimer le contenu d'un élément

// title.innerHTML = "bouton";

// Supprimer des classes sur un élément

// element.classList.add("skieur");
// element.classList.remove("pierre");
// element.classList.toggle("bouton");

let isAlive = setInterval (function() {
    let skieurTop = parseInt(window.getComputedStyle(skieur).getPropertyValue("top"));
    let pierreLeft = parseInt(window.getComputedStyle(pierre).getPropertyValue("left"));

    if (pierreLeft < 50 && pierreLeft > 0 && skieurTop >= 140) {
        alert("GAME OVER!!")
    }
}, 10)

